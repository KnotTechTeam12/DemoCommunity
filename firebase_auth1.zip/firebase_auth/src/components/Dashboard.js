import React, { useState } from "react";
import { Card, Alert, Button } from "react-bootstrap";
import { useAuth } from "../contexts/AuthContext";
import { Link, useNavigate } from "react-router-dom";

function Dashboard() {
  const [error, setError] = useState("");
  const { currentUser, logout } = useAuth();//we import the currentuser and logout through destructuring from the AuthContext component 
  const navigate = useNavigate();//this is for redirecting the content 

  const handleLogout = async () => {//this function happen when we click on the logout button and directs us to the login page 
    setError("");

    try {
      await logout();//it awaits for the logout function to work first 
      navigate("/login");
    } catch {
      setError("Failed to logout");//catch any kind of error 
    }
  };

  return (
    <>
      <Card>
        <Card.Body>
          <h2 className="text-center mb-4">Profile</h2>
          {error && <Alert variant="danger">{error}</Alert>}
          <strong>Email:</strong>
          {currentUser.email}
          {/* it shows the current user email by fetching the data from the present currentuser state  */}
          <Link to="/update-profile" className="btn btn-primary w-100 mt-3">
            Update Profile
          </Link>
        </Card.Body>
      </Card>
      <div className="w-100 text-center mt-2">
        <Button varaint="link" onClick={handleLogout}>
          Log Out
        </Button>
      </div>
    </>
  );
}

export default Dashboard;
